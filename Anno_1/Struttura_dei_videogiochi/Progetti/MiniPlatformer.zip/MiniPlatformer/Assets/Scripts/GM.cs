using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GM : MonoBehaviour
{
    // using Singleton to be able to access shared data throughout our scripts
    private static GM _instance;
    private Level_loader loader;

    public static GM Instance
    {
        get
        {
            if (_instance == null)
                Debug.LogError("GM is null");
            return _instance;
        }
    }
    // Awake is called during inizialization, before any Start call
    void Awake()
    {
        if (_instance != null)
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        _instance = this;
        loader = new Level_loader();
    }

    // global variables
    private int coins = 0;
    private int needed_coins = 0;

    private string scene_name;
    private string folder_path_scenes = "Assets/Scenes/";

    // GET // SET

    public int Coins { get; set; }
    public int Needed_coins { get; set; }

    public string Scene { get { return scene_name; } set { scene_name = value; } }
    public string Folder_path_scenes { get { return folder_path_scenes; } }

    public Level_loader Loader { get { return loader; } }
    // Methods
    public void Victory()
    {
        SceneManager.LoadScene("victory");
    }
}
