using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Deathmenu : MonoBehaviour
{
    private GM gm;

    private void Start()
    {
        gm = GM.Instance;
    }

    public void TryAgain() {
        gm.Loader.Reload_level();
    }

    public void QuitGame() { 
        Application.Quit();
    }
}
