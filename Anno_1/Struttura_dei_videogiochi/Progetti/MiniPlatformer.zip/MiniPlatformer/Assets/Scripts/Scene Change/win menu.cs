using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Winmenu : MonoBehaviour
{
    private GM gm;

    [SerializeField] private GameObject _nextLevel;

    private void Awake()
    {
        gm = GM.Instance;
        string level_number = gm.Scene.Split(' ')[1];
        int level_number_int = int.Parse(level_number) + 1;
        if (!SceneManager.GetSceneByName("level " + level_number_int).IsValid()) { 
            _nextLevel.SetActive(false);
        }
    }

    public void PlayAgain() {
        gm.Loader.Reload_level();
    }

    public void NextLevel() { 
        gm.Loader.Load_next_level();
    }

    public void QuitGame() { 
        Application.Quit();
    }
}
