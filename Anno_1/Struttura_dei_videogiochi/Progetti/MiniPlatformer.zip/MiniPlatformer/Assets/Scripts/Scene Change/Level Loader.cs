using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Level_loader
{
    private GM gm = GM.Instance;

    public bool Load_next_level()
    {
        string level_number = gm.Scene.Split(' ')[1];
        int level_number_int = int.Parse(level_number) + 1;

        if (SceneManager.GetSceneByName("level " + level_number_int).IsValid())
        {
            ResetParam();
            SceneManager.LoadScene("level " + level_number_int);
            return true;
        }
        else
        {
            Debug.Log("Missing Scene");
            return false;
        }
    }

    public bool Load_level(int num)
    {
        if (SceneManager.GetSceneByName("level " + num).buildIndex >= 0)
        {
            ResetParam();
            SceneManager.LoadScene("level " + num);
            return true;
        }
        else
        {
            Debug.Log("Missing Scene");
            return false;
        }
    }

    public void Reload_level()
    {
        ResetParam();
        SceneManager.LoadScene(gm.Scene);
    }

    private void ResetParam()
    {
        gm.Coins = 0;
    }

}
