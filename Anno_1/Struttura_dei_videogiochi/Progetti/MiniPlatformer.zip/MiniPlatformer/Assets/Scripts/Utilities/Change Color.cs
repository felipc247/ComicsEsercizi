using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeColor : MonoBehaviour
{
    GameObject square;
    // Start is called before the first frame update
    Renderer renderer = null;
    void Start()
    {
        square = gameObject;
        renderer = square.GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            renderer.material.SetColor("_Color", Color.blue);
        }
        if (Input.GetKeyUp(KeyCode.Space)) { 
            renderer.material.SetColor("_Color", Color.white);

        }
    }
}
