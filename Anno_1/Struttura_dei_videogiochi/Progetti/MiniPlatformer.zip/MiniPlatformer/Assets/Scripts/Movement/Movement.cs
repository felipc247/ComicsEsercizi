using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour
{
    // variables to control movement e jump
    private float horizontal;
    private float speed = 8f;
    private float jumping_power = 16f;
    private bool is_facing_right = true;

    private Renderer renderer;
    private SpriteRenderer spriteRenderer;
    private GM gm;

    // variables to reference game_objects
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform ground_check;
    [SerializeField] private Transform coins;
    [SerializeField] private LayerMask ground_layer;
    [SerializeField] private LayerMask death_layer;

    // variable to avoid being possible to fall when releasing space
    // if using a boost trampoline

    bool boosted = false;

    void Start()
    {
        renderer = GetComponent<Renderer>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        gm = GM.Instance;
        // set coins needed to win equal to the coins in the level
        gm.Needed_coins = coins.childCount;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Trampoline"))
        {
            boosted = true;
            Debug.Log("boosted");
        }

    }

    void Update()
    {
        // updates horizontal either to 1,0,-1 depending the direction we're moving
        horizontal = Input.GetAxisRaw("Horizontal");

        if (IsGrounded())
        {
            spriteRenderer.color = Color.red;
            if (gm.Coins == gm.Needed_coins)
            { gm.Victory(); }
            // not boosted anymore when touching ground
            boosted = false;
        }
        else if (!IsDead())
        {
            spriteRenderer.color = Color.white;
            renderer.material.SetColor("_Color", Color.white);
        }

        if (IsDead())
        {
            spriteRenderer.color = Color.black;
            SceneManager.LoadScene("death");
        }
        // makes the square jump till reaching the maximum height based on jumping power
        // and then falling down bc of gravity
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumping_power);
        }

        // makes the height of the jump variable
        // basically when you release space you the new velocity.y is smaller than the current one
        // telling the square to go down, the lower the value, the faster the fall
        if (Input.GetButtonUp("Jump") && rb.velocity.y > 0f && !boosted)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.5f);
        }

        // should make possible to flip the character, ?it disappears when facing left?
        //Flip();
    }

    private bool IsGrounded()
    {
        // creates a small circle, returns true if touching the ground else false

        return Physics2D.OverlapCircle(ground_check.position, 0.3f, ground_layer);
    }

    private bool IsDead()
    {
        // creates a small circle, returns true if touching the death else false

        return Physics2D.OverlapCircle(ground_check.position, 0.5f, death_layer);
    }

    // makes the square move horizontally based on speed value
    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
    }

    // flips the player horizontally
    private void Flip()
    {
        if (horizontal < 0f && is_facing_right || horizontal > 0f && !is_facing_right)
        {
            is_facing_right = !is_facing_right;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }
}
