using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform_move : MonoBehaviour
{
    private float speed = 3f;
    private float range = 5;
    private float original_position;
    private float direction = -1;

    float x;

    private Rigidbody2D rb;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        original_position = rb.position.x;
        rb.velocity = new Vector2(direction * speed, rb.velocity.y);
    }

    // Update is called once per frame
    void Update()
    {
        x = rb.position.x;
    }

    private void FixedUpdate()
    {
        if (x < original_position)
        {
            if (original_position - x >= range)
            {
                direction = -direction;
                rb.velocity = new Vector2(direction * speed, rb.velocity.y);
            }
        }
        else
        {
            if (x - original_position >= range)
            {
                direction = -direction;
                rb.velocity = new Vector2(direction * speed, rb.velocity.y);
            }
        }
    }

    
}
