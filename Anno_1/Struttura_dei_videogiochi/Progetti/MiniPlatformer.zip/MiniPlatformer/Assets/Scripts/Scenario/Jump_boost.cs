using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Jump_boost : MonoBehaviour
{
    private float jump_boost = 30f;

    private void OnCollisionEnter2D(Collision2D collision2D) {
        if (collision2D.gameObject.CompareTag("Player")) {
            collision2D.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up * jump_boost, ForceMode2D.Impulse);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
