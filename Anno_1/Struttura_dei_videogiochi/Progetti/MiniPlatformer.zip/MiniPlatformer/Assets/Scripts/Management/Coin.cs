using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Coin : MonoBehaviour
{
    private Renderer rd;
    private GM gm;

    // avoids checking time part if coin not collected
    private bool isCollected = false;

    // time
    private float respawnTimer = 0f;
    private float respawnDelay = 3f; // 3 secs

    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.CompareTag("Player") && !isCollected)
        {
            gm.Coins++;
            isCollected = true;
            Debug.Log("Coins: " + gm.Coins);
            rd.enabled = false;
            respawnTimer = respawnDelay;
        }
    }


    private void ReactivateCoin()
    {
        rd.enabled = true;
    }


    // Start is called before the first frame update
    void Start()
    {
        rd = GetComponent<Renderer>();
        gm = GM.Instance;
    }

    // Update is called once per frame
    void Update()
    {
        // MAKES THE COIN REAPPEAR AFTER DELAY
        //if (isCollected)
        //{
        //    respawnTimer -= Time.deltaTime;
        //    if (respawnTimer <= 0f)
        //    {
        //        ReactivateCoin();
        //        isCollected = false;
        //    }
        //}
    }
}
