using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Sceneupdate : MonoBehaviour
{
    private GM gm;

    void Awake()
    {
        gm = GM.Instance;
        gm.Scene = SceneManager.GetActiveScene().name;
        Debug.Log(gm.Scene);
    }

}
