﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Utilities
{
    internal class PS
    {
        public static void kart() {
            Console.WriteLine();
        }
    }
}
