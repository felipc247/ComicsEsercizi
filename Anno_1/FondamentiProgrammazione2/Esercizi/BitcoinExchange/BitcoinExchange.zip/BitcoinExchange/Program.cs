﻿// See https://aka.ms/new-console-template for more information

// chiedere all'utente quale file usare come test:

using System.Collections.Generic;
using System.Globalization;
using System.Security;
using System.Security.Cryptography.X509Certificates;


//string test_file = Console.ReadLine();

//FILE* file = fopen(test_file, "r");

// voi implementate la lettura dai file e il parsing dal file con i test

string[] csv = { "2001-01-01", "0.21", "2005-01-01", "15.21", "2016-01-01", "30.5", "2020-01-01", "300.21", "2021-01-01", "4000.21" };

string[] test = { "2001-01-01", "5", "2001-01-01", "10", "2016-01-01", "0.21", "2021-01-01", "0.21" };


Dictionary<string, float> map = insertFileinMap(csv);

Console.WriteLine(getExchangeValue(map, "2023-01-02", 1));

Dictionary<string, float> insertFileinMap(string[] data)
{
    Dictionary<string, float> map = new Dictionary<string, float>();

    for (int i = 0; i < data.Length; i += 2)
    {
        map[data[i]] = float.Parse(data[i + 1], CultureInfo.InvariantCulture.NumberFormat);
    }
    foreach (var val in map)
    {
        Console.WriteLine(val);
    }
    return map;
}

float getExchangeValue(Dictionary<string, float> map, string date, float amount)
{
    if (map.ContainsKey(date)) return map[date] * amount;

    string closest_date = "";
    string previous_date = "";

    int i = 0;

    foreach (var item in map)
    {
        if (i == 0)
        {
            if (DateTime.Parse(date) < DateTime.Parse(item.Key))
            {
                closest_date = item.Key;
                break;
            }

            previous_date = item.Key;
            i++;
        }
        else
        {

            if (DateTime.Parse(date) < DateTime.Parse(item.Key))
            {
                if (map[previous_date] < map[item.Key])
                    closest_date = previous_date;
                else
                    closest_date = item.Key;

                break;
            }
            previous_date = item.Key;

        }

    }

    if (closest_date.Equals("")) closest_date = previous_date;

    return map[closest_date] * amount;



}