﻿using Simple_RTS.Base;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Truppe_Elite.Guerra.Tank
{
    internal class Colosso : Truppa_Elite_Guerra
    {
        private int vita_scudo = 3000;

        public Colosso()
        {
            base.nome = GetType().Name;
            base.nome_abilita = "Scudo di Ghiaccio";

            base.descrizione = "Un gigante nato nei freddi ghiacchi nordici, ogni nemico che ha affrontato" +
                "è letteralmente caduto ai suoi piedi";

            base.descrizione_abilita = $"Evoca un enorme scudo ghiacciato che ripara le tue Truppe da {vita_scudo} danni";

            base.descrizione_uso_abilita = $"Uno scudo ghiacciato ha protetto le tue Truppe";

            base.costo = 3000;
            base.costo_abilita = 1000;
            base.tipologia = TT.Guerra;
            base.tipologia_Guerra = TT_Guerra.Tank;
            base.cooldown = 2;
            base.cooldown_Rimanente = 0;
        }

        public override void Attiva()
        {
            base.Attiva();
            CC.RedFr(base.descrizione_uso_abilita);
        }


    }
}
