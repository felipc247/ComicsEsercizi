﻿using Simple_RTS.Base;
using Simple_RTS.Erori;
using Simple_RTS.Exceptions;
using Simple_RTS.Exceptions.Eroi;
using Simple_RTS.Exceptions.Frammenti;
using Simple_RTS.Exceptions.Input;
using Simple_RTS.Exceptions.Truppe;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;

namespace Simple_RTS.Combattimento
{
    internal class Attacco
    {
        private Giocatore giocatore1, giocatore2;

        public Attacco() { }

        public void SetUp(Giocatore giocatore1, Giocatore giocatore2)
        {
            this.giocatore1 = giocatore1;
            this.giocatore2 = giocatore2;
        }

        private void PrintTipologieTruppa()
        {
            int i = 1;

            // TRUPPE MISCHIA
            CC.DarkYellowFr($"{i++}. {giocatore1.Truppe_Mischia[0].Tipologia}\n");

            // TRUPPE DISTANZA
            CC.DarkCyanFr($"{i++}. {giocatore1.Truppe_Distanza[0].Tipologia}\n");

            // TRUPPE TANK
            CC.DarkMagentaFr($"{i++}. {giocatore1.Truppe_Tank[0].Tipologia}\n");
        }

        private void PrintTruppeSchieraTruppe(List<Truppa> truppas)
        {
            int i = 1;
            switch (truppas[0].Tipologia)
            {
                case Truppa.TT.Mischia:
                    CC.DarkYellowFr("Truppe Mischia:\n");
                    foreach (var t in truppas)
                    {
                        CC.YellowFr($"{i++}. {t.Nome}");
                        CC.WhiteFr($" | Hai Qt. {t.Disponibili} disponibili ({t.Schierate} schierate, {t.Ferite} ferite)\n");
                    }
                    break;
                case Truppa.TT.Distanza:
                    CC.DarkCyanFr("Truppe Distanza:\n");
                    foreach (var t in truppas)
                    {
                        CC.CyanFr($"{i++}. {t.Nome}");
                        CC.WhiteFr($" | Hai Qt. {t.Disponibili} disponibili ({t.Schierate} schierate, {t.Ferite} ferite)\n");
                    }
                    break;
                case Truppa.TT.Tank:
                    CC.DarkMagentaFr("Truppe Tank:\n");
                    foreach (var t in truppas)
                    {
                        CC.MagentaFr($"{i++}. {t.Nome}");
                        CC.WhiteFr($" | Hai Qt. {t.Disponibili} disponibili ({t.Schierate} schierate, {t.Ferite} ferite)\n");
                    }
                    break;
            }
        }

        private int SchieraTruppe(List<Truppa> truppe)
        {
            int scelta;
            int truppeCount = truppe.Count;
            do
            {
                scelta = -1;
                try
                {
                    // Stampa Classi Truppe della Tipologia scelta
                    PrintTruppeSchieraTruppe(truppe);
                    CC.BlueFr("0. Indietro\n");

                    CC.CyanFr("Inserisci 'numTruppa'.'Quantita'\n" +
                        "Invio e ripeti per altre Truppe\n" +
                        "Invio senza nulla per terminare\n");

                    int qt = 0;
                    // per salvare le truppe e le quantita scelta dall'utente
                    Dictionary<int, int> qts = new Dictionary<int, int>();

                    String sceltaStr;

                    bool first = true;

                    do
                    {
                        // lettura scelta
                        sceltaStr = Console.ReadLine();

                        if (first)
                        {
                            // se al primo input non si inserisce nulla
                            // allora exception
                            first = false;
                            if (sceltaStr.Equals("")) throw new StringaVuotaException();
                        }
                        else
                        {
                            // se non si inserisce nulla dopo, allora fine input
                            if (sceltaStr.Equals("")) break;
                        }

                        // Tentativo di split
                        String[] input = sceltaStr.Split('.');

                        // gestione eccezioni input

                        if (!int.TryParse(input[0], out scelta)) throw new InputNonValidoException();
                        if (scelta < 0 || scelta > truppeCount) throw new NumeroNonValidoException();
                        if (scelta == 0) break;
                        if (input.Length != 2) throw new FormattazioneNonValidaException();
                        if (!int.TryParse(input[1], out qt)) throw new InputNonValidoException();

                        // se tutto va bene aggiungo al Dictionary
                        if (qts.ContainsKey(scelta))
                        {
                            qts[scelta] += qt;
                        }
                        else
                        {
                            qts.Add(scelta, qt);
                        }

                    } while (true);

                    // indietro scelta == 0
                    if (scelta == 0) break;


                    // Stampa riepilogo schieramento
                    int totale = 0;

                    foreach (var item in qts)
                    {
                        CC.CyanFr($"{truppe[item.Key - 1].Nome}"); CC.WhiteFr($" => {item.Value}\n");
                        if (truppe[item.Key - 1].Disponibili < item.Value) throw new TruppeInsufficientiException();
                        totale += item.Value;
                    }

                    CC.BlueFr("Schierare queste Truppe?\n");

                    CC.DarkYellowFr($"Totale: {totale} Truppe\n");

                    CC.WhiteFr("1. Si\n" +
                        "2. No\n");

                    sceltaStr = Console.ReadLine();
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 1 || scelta > 2) throw new NumeroNonValidoException();

                    // Si
                    if (scelta == 1)
                    {
                        foreach (var item in qts)
                        {
                            truppe[item.Key - 1].Disponibili = -item.Value;
                            truppe[item.Key - 1].Schierate = item.Value;
                        }
                        //int i = 0;
                        //switch (truppe[0].Tipologia)
                        //{
                        //    case Truppa.TT.Mischia:
                        //        foreach (var item in qts)
                        //        {
                        //            truppe[item.Key - 1].Disponibili = -item.Value;
                        //            truppe[item.Key - 1].Schierate = item.Value;
                        //        }
                        //        break;
                        //    case Truppa.TT.Distanza:
                        //        foreach (var item in qts)
                        //        {
                        //            giocatore.Truppe_Distanza_Inviate[item.Key - 1].Quantita = item.Value;
                        //            truppe[item.Key - 1].Quantita = -item.Value;
                        //        }
                        //        break;
                        //    case Truppa.TT.Tank:
                        //        foreach (var item in qts)
                        //        {
                        //            giocatore.Truppe_Tank_Inviate[item.Key - 1].Quantita = item.Value;
                        //            truppe[item.Key - 1].Quantita = -item.Value;
                        //        }
                        //        break;
                        //}

                        CC.GreenFr("Truppe Schierate\n");

                    }
                }

                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                catch (FormattazioneNonValidaException) { scelta = -1; }
                catch (TruppeInsufficientiException) { }
                finally { if (scelta < 0 || scelta > 2) scelta = -1; }

            } while (scelta == -1);

            return scelta;
        }

        private int PrintSchieraTruppe(Giocatore giocatore)
        {
            int scelta;
            int numTipologie = 3;
            do
            {
                scelta = -1;
                try
                {

                    // Stampa Truppe
                    CC.CyanFr("Cosa vuoi schierare?\n");
                    PrintTipologieTruppa();
                    CC.BlueFr($"0. Indietro\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 0 || scelta > numTipologie) throw new NumeroNonValidoException();

                    // Indietro
                    if (scelta == 0) break;

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            scelta = SchieraTruppe(giocatore.Truppe_Mischia);
                            break;
                        case 2:
                            scelta = SchieraTruppe(giocatore.Truppe_Distanza);
                            break;
                        case 3:
                            scelta = SchieraTruppe(giocatore.Truppe_Tank);
                            break;

                    }
                    // se non si è scelto Avanti, si ripete il ciclo
                    scelta = -1;

                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                finally { if (scelta < 0 || scelta > numTipologie) scelta = -1; }

            } while (scelta == -1);

            return scelta;
        }

        private void PrintTipologieEroi()
        {
            int i = 1;
            // Guerra
            CC.DarkMagentaFr($"{i++}. {giocatore1.Eroi_Attacco[0].Tipologia}\n");

            // Supporto
            CC.DarkCyanFr($"{i++}. {giocatore1.Eroi_Difesa[0].Tipologia}\n");
        }

        private void PrintEroi(List<Eroe> eroi)
        {
            int i = 1;
            foreach (var eroe in eroi)
            {
                // stampo Nome Eroe, il colore cambia in base alla Tipologia
                switch (eroe.Tipologia)
                {
                    case Eroe.TT.Attacco:
                        CC.MagentaFr($"{i++} . {eroe.Nome}");
                        break;
                    case Eroe.TT.Difesa:
                        CC.CyanFr($"{i++} . {eroe.Nome}");
                        break;
                }

                CC.WhiteFr(" | ");
                if (eroe.Evocato)
                {
                    CC.GreenFr("Con te\n");
                }
                else
                {
                    CC.RedFr("Da evocare\n");
                }
            }
        }

        private int SceltaEroi(List<Eroe> eroi)
        {
            int scelta;
            int eroiCount = eroi.Count;
            do
            {
                scelta = -1;
                try
                {
                    // Stampa Eroi della Tipologia scelta
                    PrintEroi(eroi);
                    CC.BlueFr("0. Indietro\n");

                    CC.CyanFr("Inserisci numEroe\n" +
                        "Invio e ripeti per altri Eroi (MAX 3)\n" +
                        "Invio senza nulla per terminare\n");

                    // per salvare le truppe e le quantita scelta dall'utente
                    List<int> eroi_Scelti = new List<int>();

                    String sceltaStr;

                    bool first = true;

                    int i = 1;
                    do
                    {
                        // lettura scelta
                        sceltaStr = Console.ReadLine();

                        if (first)
                        {
                            // se al primo input non si inserisce nulla
                            // si esce, nessun Eroe selezionato

                            if (sceltaStr.Equals(""))
                            {
                                CC.MagentaFr("Non hai scelto nessun Eroe\n");
                                scelta = 0;
                                break;
                            }
                            first = false;
                        }
                        else
                        {
                            // se non si inserisce nulla dopo, allora fine input
                            if (sceltaStr.Equals("")) break;
                        }


                        // gestione eccezioni input

                        if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                        if (scelta < 0 || scelta > eroiCount) throw new NumeroNonValidoException();

                        // indietro, si esce
                        if (scelta == 0) break;

                        // se tutto va bene aggiungo al Dictionary
                        if (!eroi_Scelti.Contains(scelta))
                        {
                            eroi_Scelti.Add(scelta);
                            i++;
                        }

                    } while (i < 4);

                    // indietro scelta == 0 o Nessun Eroe selezionato
                    if (scelta == 0) break;

                    // Stampa riepilogo scelta Eroi

                    i = 1;

                    CC.BlueFr("Scegliere questi Eroi?\n");
                    foreach (var item in eroi_Scelti)
                    {
                        CC.CyanFr($"{i++}. {eroi[item - 1].Nome}\n");
                    }

                    CC.WhiteFr("1. Si\n" +
                        "2. No\n");

                    sceltaStr = Console.ReadLine();
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 1 || scelta > 2) throw new NumeroNonValidoException();

                    // Si
                    if (scelta == 1)
                    {
                        foreach (var item in eroi_Scelti)
                        {
                            if (!eroi[item - 1].Evocato) throw new EroeNonEvocatoException();
                        }

                        foreach (var item in eroi_Scelti)
                        {
                            eroi[item - 1].Schierato();
                        }

                        //switch (eroi[0].Tipologia)
                        //{
                        //    case Eroe.TT.Attacco:
                        //        foreach (var item in eroi_Scelti)
                        //        {
                        //            eroi[item - 1].Schierato();
                        //        }
                        //        break;
                        //    case Eroe.TT.Difesa:

                        //        break;
                        //}

                        CC.GreenFr($"Eroi Schierati\n");
                    }

                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                catch (EroeNonEvocatoException) { }
                finally { if (scelta < 0 || scelta > 2) scelta = -1; }

            } while (scelta == -1);

            return scelta;
        }

        private int PrintSceltaEroi(Giocatore giocatore)
        {
            int scelta;
            int tipologieEroe = 2;
            do
            {
                scelta = -1;
                try
                {
                    // stampa slots
                    CC.CyanFr("Scegli tipologia Eroe\n");
                    PrintTipologieEroi();
                    CC.BlueFr($"0. Indietro\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 0 || scelta > tipologieEroe + 1) throw new NumeroNonValidoException();

                    // Indietro
                    if (scelta == 0) break;

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            scelta = SceltaEroi(giocatore.Eroi_Attacco);
                            break;
                        case 2:
                            scelta = SceltaEroi(giocatore.Eroi_Difesa);
                            break;
                        case 0:
                            // indietro
                            break;

                    }

                    // si è scelto indietro ()
                    scelta = -1;
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                finally { if (scelta != tipologieEroe + 1) scelta = -1; }

            } while (scelta == -1);

            return scelta;
        }

        // Stampa scelte disponibili
        private void PrintPreparazione()
        {
            int i = 1;
            CC.DarkCyanFr($"{i++}. Schiera Eroi\n");
            CC.YellowFr($"{i++}. Schiera Truppe\n");
        }

        // Permette di scegliere quali Truppe ed Eroi schierare
        public void Preparazione(Giocatore giocatore)
        {
            int scelta;
            int numScelte = 2;
            do
            {
                scelta = -1;
                try
                {

                    // Stampa Truppe
                    CC.CyanFr("Cosa vuoi schierare?\n");
                    PrintPreparazione();
                    CC.BlueFr($"{numScelte + 1}. Avanti\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 1 || scelta > numScelte + 1) throw new NumeroNonValidoException();

                    // Avanti
                    if (scelta == numScelte + 1)
                    {
                        // Controllo che almeno una Truppa sia stata schierata prima di attaccare
                        int totale = 0;

                        foreach (var item in giocatore.Truppe_Mischia)
                        {
                            totale += item.Schierate;
                        }
                        foreach (var item in giocatore.Truppe_Distanza)
                        {
                            totale += item.Schierate;
                        }
                        foreach (var item in giocatore.Truppe_Tank)
                        {
                            totale += item.Schierate;
                        }

                        if (totale > 0) { break; }
                        else { throw new TruppeNecessarieException(); }
                    }

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            scelta = PrintSceltaEroi(giocatore);
                            break;
                        case 2:
                            scelta = PrintSchieraTruppe(giocatore);
                            break;

                    }
                    // se non si è scelto Avanti, si ripete il ciclo
                    scelta = -1;

                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                catch (TruppeNecessarieException) { scelta = -1; }
                finally { if (scelta != numScelte + 1) scelta = -1; }

            } while (scelta == -1);
        }

        private int[] movimenti = new int[17];

        private void InizializzaMovimenti()
        {
            for (int i = 0; i < movimenti.Length; i++)
            {
                movimenti[i] = 0;
            }
        }

        public void StimaTruppeNemiche()
        {
            int totale = 0;

            Random ra = new Random();
            CC.DarkYellowFr("Truppe Mischia:\n");
            foreach (var truppa in giocatore1.Truppe_Mischia)
            {
                int totaleTruppa = 0;
                double precisione = ra.Next(0, 31);
                precisione /= 100;
                int piu_meno = ra.Next(0, 2); // 0 = rimuovo, 1 = aggiungo Truppe
                totaleTruppa = (piu_meno == 0) ? (int)(truppa.Schierate + truppa.Schierate * precisione) : (int)(truppa.Schierate - truppa.Schierate * precisione);
                totale += totaleTruppa;
                CC.YellowFr($"{truppa.Nome} Qt. {totaleTruppa}\n");
            }
            PS.kart();
            CC.DarkCyanFr("Truppe Distanza:\n");
            foreach (var truppa in giocatore1.Truppe_Distanza)
            {
                int totaleTruppa = 0;
                double precisione = ra.Next(1, 31);
                precisione /= 100;
                int piu_meno = ra.Next(0, 2); // 0 = rimuovo, 1 = aggiungo Truppe
                totaleTruppa = (piu_meno == 0) ? (int)(truppa.Schierate + truppa.Schierate * precisione) : (int)(truppa.Schierate - truppa.Schierate * precisione);
                totale += totaleTruppa;
                CC.CyanFr($"{truppa.Nome} Qt. {totaleTruppa}\n");
            }
            PS.kart();
            CC.DarkMagentaFr("Truppe Tank:\n");
            foreach (var truppa in giocatore1.Truppe_Tank)
            {
                int totaleTruppa = 0;
                double precisione = ra.Next(1, 31);
                precisione /= 100;
                int piu_meno = ra.Next(0, 2); // 0 = rimuovo, 1 = aggiungo Truppe
                totaleTruppa = (piu_meno == 0) ? (int)(truppa.Schierate + truppa.Schierate * precisione) : (int)(truppa.Schierate - truppa.Schierate * precisione);
                totale += totaleTruppa;
                CC.MagentaFr($"{truppa.Nome} Qt. {totaleTruppa}\n");
            }
            PS.kart();
            CC.RedFr($"Totale Truppe {totale}\n");

        }

        public void SetupViteTruppe()
        {
            int j = 0;
            foreach (var item in giocatore1.Truppe_Mischia)
            {
                giocatore1.Truppe_Mischia[j].Vite.Clear();
                for (int i = 0; i < giocatore1.Truppe_Mischia[j].Schierate; i++)
                {
                    giocatore1.Truppe_Mischia[j].Vite.Add(giocatore1.Truppe_Mischia[j].Vita);
                }
                j++;
            }

            j = 0;
            foreach (var item in giocatore1.Truppe_Distanza)
            {
                giocatore1.Truppe_Distanza[j].Vite.Clear();
                for (int i = 0; i < giocatore1.Truppe_Distanza[j].Schierate; i++)
                {
                    giocatore1.Truppe_Distanza[j].Vite.Add(giocatore1.Truppe_Distanza[j].Vita);
                }
                j++;
            }

            j = 0;
            foreach (var item in giocatore1.Truppe_Tank)
            {
                giocatore1.Truppe_Tank[j].Vite.Clear();
                for (int i = 0; i < giocatore1.Truppe_Tank[j].Schierate; i++)
                {
                    giocatore1.Truppe_Tank[j].Vite.Add(giocatore1.Truppe_Tank[j].Vita);
                }
                j++;
            }

            j = 0;
            foreach (var item in giocatore2.Truppe_Mischia)
            {
                giocatore2.Truppe_Mischia[j].Vite.Clear();
                for (int i = 0; i < giocatore2.Truppe_Mischia[j].Schierate; i++)
                {
                    giocatore2.Truppe_Mischia[j].Vite.Add(giocatore2.Truppe_Mischia[j].Vita);
                }
                j++;
            }

            j = 0;
            foreach (var item in giocatore2.Truppe_Distanza)
            {
                giocatore2.Truppe_Distanza[j].Vite.Clear();
                for (int i = 0; i < giocatore2.Truppe_Distanza[j].Schierate; i++)
                {
                    giocatore2.Truppe_Distanza[j].Vite.Add(giocatore2.Truppe_Distanza[j].Vita);
                }
                j++;
            }

            j = 0;
            foreach (var item in giocatore2.Truppe_Tank)
            {
                giocatore2.Truppe_Tank[j].Vite.Clear();
                for (int i = 0; i < giocatore2.Truppe_Tank[j].Schierate; i++)
                {
                    giocatore2.Truppe_Tank[j].Vite.Add(giocatore2.Truppe_Tank[j].Vita);
                }
                j++;
            }

        }

        int mov = 16;

        public void Avanza()
        {
            movimenti[mov] = 0;
            mov--;
            movimenti[mov] = 1;
            spezza();
            CC.BlueFr($"{mov}\n");
            spezza();

        }

        // Le Truppe Mischia ed i Tank non possono colpire fino a che non si a

        public void CalcoloDanni()
        {
            // Prima le Truppe Tank attaccano, poi le Truppe Mischia, poi le Truppe distanza
            // Il calcolo dei danni avviene simultaneamente

            // Calcolo totale dei danni, e poi distribuzione equa in base al range a botte di 5 ad ogni Truppa
            // Se i danni sono sufficienti e più ad uccidere le Truppe di una Classe si passa alla successiva

            // del tipo 5000 danni, su 5 mammut, ognuno riceve 1000 danni
            // o 2 Mammut, 3500 danni, 3000 li prendono i mammut, e gli altri 500 i Soldati_semplici
            // In case di range uguale, le Truppe con costo minore vengono colpite prime
            // Se hanno anche stesso costo si estre random

            // 
            int danni_g1 = 0;
            int danni_g2 = 0;

            // CALCOLO DANNI

            // Giocatore 1

            CC.DarkCyanFr($"{giocatore1.Nome}:\n");
            foreach (var truppa in giocatore1.Truppe_Tank)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g1 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            foreach (var truppa in giocatore1.Truppe_Mischia)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g1 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            foreach (var truppa in giocatore1.Truppe_Distanza)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g1 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            // Giocatore 2

            CC.BlueFr($"{giocatore2.Nome}:\n");

            foreach (var truppa in giocatore2.Truppe_Tank)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g2 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            foreach (var truppa in giocatore2.Truppe_Mischia)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g2 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            foreach (var truppa in giocatore2.Truppe_Distanza)
            {
                if (truppa.Schierate > 0)
                {
                    if (truppa.Range >= GetDistance())
                    {
                        CC.GreenFr($"{truppa.Nome} In range\n");
                        danni_g2 += (truppa.Atk * truppa.Schierate);
                    }
                    else
                    {
                        CC.RedFr($"{truppa.Nome} Non range\n");
                    }
                }
            }

            // Salvo per dati
            int danni_g1_save = danni_g1;
            int danni_g2_save = danni_g2;

            CC.MagentaFr("DANNI:\n");
            CC.RedFr($"danni g1:{danni_g1}\n" +
                $"danni g2:{danni_g2}\n");

            // DISTRIBUZIONE DANNI

            List<Truppa> confrontoRange = new List<Truppa>();

            //foreach (var truppa in giocatore2.Truppe_Tank)
            //{
            //    confrontoRange.Add(new Truppa(truppa));
            //}
            RangeSort(giocatore2.Truppe_Tank);

            CC.BlueFr($"{giocatore2.Nome}:\n");

            foreach (var truppa in giocatore2.Truppe_Tank)
            {
                if (danni_g1 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g1 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g1 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g1 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0) {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else { 
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }
            }

            RangeSort(giocatore2.Truppe_Mischia);

            foreach (var truppa in giocatore2.Truppe_Mischia)
            {
                if (danni_g1 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g1 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g1 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g1 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0)
                {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else
                {
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }

            }
            RangeSort(giocatore2.Truppe_Distanza);

            foreach (var truppa in giocatore2.Truppe_Distanza)
            {
                if (danni_g1 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g1 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g1 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g1 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0)
                {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else
                {
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }
            }

            // se g2 non ha subito danni
            if (danni_g1 == danni_g1_save) CC.GreenFr("Nessun danno subito\n");

            CC.CyanFr($"{giocatore1.Nome}:\n");

            RangeSort(giocatore1.Truppe_Tank);

            foreach (var truppa in giocatore1.Truppe_Tank)
            {
                if (danni_g2 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g2 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g2 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g2 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0)
                {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else
                {
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }
            }
            RangeSort(giocatore1.Truppe_Mischia);

            foreach (var truppa in giocatore1.Truppe_Mischia)
            {
                if (danni_g2 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g2 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g2 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g2 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0)
                {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else
                {
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }
            }
            RangeSort(giocatore1.Truppe_Distanza);

            foreach (var truppa in giocatore1.Truppe_Distanza)
            {
                if (danni_g2 == 0) break;
                if (truppa.Schierate == 0) continue;
                int j = 0;
                int truppe_uccise = 0;
                int truppe_ferite = 0;
                int danni_subiti = 0;
                do
                {
                    for (int i = 0; i < truppa.Vite.Count; i++)
                    {
                        if (danni_g2 == 0) break;
                        if (truppa.Vite[i] - 5 == 0)
                        {
                            truppa.Schierate = -1;
                            truppa.Vite.RemoveAt(i);
                            truppe_uccise += 1;
                            //CC.RedFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} uccisa\n");
                        }
                        else
                        {
                            truppa.Vite[i] -= 5;
                            //CC.DarkCyanFr($"{j} {giocatore2.Nome} Truppa {i},{truppa.Nome} danneggiata\n");
                        }
                        j++;
                        danni_g2 -= 5;
                        danni_subiti += 5;
                        if (truppa.Vite.Count == 0) { break; }
                    }
                } while (danni_g2 > 0 && truppa.Vite.Count > 0);

                if (truppe_uccise > 0)
                {
                    CC.RedFr($"{truppa.Nome} - {truppe_uccise} Mort* | ");
                    CC.YellowFr($"Danni subiti: {danni_subiti}\n");
                }
                else
                {
                    CC.YellowFr($"{truppa.Nome} | Danni subiti: {danni_subiti}\n");
                }
            }

            // se g1 non ha subito danni
            if (danni_g2 == danni_g2_save) CC.GreenFr("Nessun danno subito\n");
        }

        // Ordina una Tipologia di truppe, in base al Range
        // mi serve per dare la precedenza ai danni
        // e.g. I tank subiranno i danni per primi
        public void RangeSort(List<Truppa> truppe)
        {
            Random ra = new Random();
            for (int i = 0; i < truppe.Count - 1; i++)
            {
                // Trova l'indice del minimo elemento nella parte non ordinata
                int minIndex = i;
                for (int j = i + 1; j < truppe.Count; j++)
                {
                    if (truppe[j].Range < truppe[minIndex].Range)
                    {
                        minIndex = j;
                    }
                    // Se il range è uguale si controlla il costo
                    else if (truppe[j].Range == truppe[minIndex].Range)
                    {
                        if (truppe[j].Costo < truppe[minIndex].Range)
                        {
                            minIndex = j;
                        }
                        // Se anche il costo è uguale si fa Random
                        else if (truppe[j].Costo == truppe[minIndex].Range)
                        {
                            int caso = ra.Next(0, 2);
                            if (caso == 0)
                            {
                                minIndex = j;
                            }
                        }
                    }
                }

                // Scambia l'elemento minimo con l'elemento all'inizio della parte non ordinata
                Truppa temp = truppe[minIndex];
                truppe[minIndex] = truppe[i];
                truppe[i] = temp;
            }
        }

        public void spezza() {
            CC.WhiteFr("------------------------------------------\n");
        }

        public int GetDistance()
        {
            return mov - 1;
        }

        public void AAAttacco()
        {
            InizializzaMovimenti();
            movimenti[1] = 2; // posizione Truppe nemiche, 1
            for (int i = movimenti.Length - 1; i > -1; i--)
            {
                switch (i)
                {
                    case 16: // Avvistamento
                        CC.RedFr($"{giocatore1.Nome} Ti sta attaccando!\n");
                        StimaTruppeNemiche();
                        Preparazione(giocatore2);
                        Avanza();
                        break;
                    case 15: // Avvicinamento
                        SetupViteTruppe();
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 14:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 13:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 12:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 11:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 10:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 9:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 8:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 7:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 6:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 5:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 4:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 3:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 2:
                        CalcoloDanni();
                        Avanza();
                        break;
                    case 1:
                        CalcoloDanni();
                        Avanza();
                        break;
                }
            }


        }
    }
}
