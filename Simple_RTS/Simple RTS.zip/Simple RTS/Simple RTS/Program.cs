﻿using Simple_RTS.Base;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // GIOCATORE 1
            Altare altare1 = new Altare();
            Fornace fornace1 = new Fornace();
            Giocatore giocatore1 = new Giocatore(fornace1, altare1);
            giocatore1.Fornace.Fusione();
            PS.kart();
            giocatore1.Altare.FuriaDivina();
            PS.kart();
            Mercato mercato1 = new Mercato(giocatore1);

            mercato1.SceltaSlot();
            mercato1.SceltaSlot();
            mercato1.SceltaSlot();
            mercato1.SceltaSlot();
            mercato1.SceltaSlot();
            mercato1.SceltaSlot();
            mercato1.SceltaSlot();

            // GIOCATORE 2
            Altare altare2 = new Altare();
            Fornace fornace2 = new Fornace();
            Giocatore giocatore2 = new Giocatore(fornace2, altare2);
            Mercato mercato2 = new Mercato(giocatore2);
            mercato2.SceltaSlot();
            mercato2.SceltaSlot();
        }
    }
}
