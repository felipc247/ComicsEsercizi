﻿using Simple_RTS.Base;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // GIOCATORE 1
            Altare altare1 = new Altare();
            Fornace fornace1 = new Fornace();
            Torre torre1 = new Torre();            

            // GIOCATORE 2
            Altare altare2 = new Altare();
            Fornace fornace2 = new Fornace();
            Torre torre2 = new Torre();

            Giocatore giocatore1 = new Giocatore(fornace1, altare1, torre1, torre2);
            Giocatore giocatore2 = new Giocatore(fornace2, altare2, torre2, torre1);
            giocatore1.SetUp(giocatore2.Truppe_Mischia);
            giocatore2.SetUp(giocatore1.Truppe_Mischia);

            giocatore2.Truppe_Mischia[0].Quantita = 1500;
            giocatore2.Truppe_Mischia[1].Quantita = 1500;

            giocatore1.Truppe_Elite_Guerra_Mischia[0].Attiva();

            giocatore1.Truppe_Elite_Supporto[0].Attiva();

            giocatore1.Fornace.Fusione();
            PS.kart();
            giocatore1.Altare.FuriaDivina();
            PS.kart();
            Mercato mercato1 = new Mercato(giocatore1);

            mercato1.SceltaSlot();
            Mercato mercato2 = new Mercato(giocatore2);
        }
    }
}
