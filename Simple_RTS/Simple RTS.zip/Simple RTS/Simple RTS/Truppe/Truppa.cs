﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Truppe
{
    internal class Truppa
    {
        protected String nome;
        protected int costo;
        protected int vita;
        protected int atk;
        protected int livello = 1;
        protected int range;
        protected int quantita = 0;
        protected int costo_Potenziamento;
        protected int[] costi_Potenziamento;
        protected TT tipologia;

        public enum TT
        {
            Mischia,
            Distanza,
            Tank
        }

        public Truppa() { }

        // GET // SET
        public String Nome { get { return nome; } }

        public int Costo { get { return costo; } }

        public int Vita { get { return vita; } }

        public int Atk { get { return atk; } }

        public int Livello { get { return livello; } }

        public int Range { get { return range; } }

        public int Quantita { get { return quantita; } set { quantita += value; if (quantita < 0) quantita = 0; } }

        public int Costo_Potenziamento { get { return costo_Potenziamento; } }

        public int[] Costi_Potenziamento { get { return costi_Potenziamento; } }

        public TT Tipologia { get { return tipologia; } }


        // METODI

        public virtual void Potenzia() { }


    }
}
