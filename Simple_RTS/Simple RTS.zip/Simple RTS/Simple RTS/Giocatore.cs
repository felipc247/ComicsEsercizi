﻿using Simple_RTS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Truppe
{
    internal class Giocatore
    {
        // Risorse sono nelle strutture
        
        // Truppe
        private List<Truppa> truppe_Mischia = new List<Truppa>();
        private List<Truppa> truppe_Distanza = new List<Truppa>();
        private List<Truppa> truppe_Tank = new List<Truppa>();
        // Truppe Elite
        private List<Truppa_Elite> truppe_Elite = new List<Truppa_Elite>();
        // Strutture
        // il Mercato è l'unica struttura che non viene assegnata a Giocatore
        private Fornace fornace = new Fornace();
        private Altare altare = new Altare();
        

        public Giocatore(Fornace fornace, Altare altare) {
            this.fornace = fornace;
            this.altare = altare;

            Add_Truppe_Mischia();
            Add_Truppe_Distanza();
            Add_Truppe_Tank();
        }

        private void Add_Truppe_Mischia() {
            truppe_Mischia.Add(new Soldato_Semplice());
            truppe_Mischia.Add(new Spadaccino());
        }

        private void Add_Truppe_Distanza() {
            truppe_Distanza.Add(new Arciere());
        }

        private void Add_Truppe_Tank() {
            truppe_Tank.Add(new Mammut());
        }

        // GET // SET

        // Truppe normali
        public List<Truppa> Truppe_Mischia { get { return truppe_Mischia; } }
        public List<Truppa> Truppe_Distanza { get { return truppe_Distanza; } }
        public List<Truppa> Truppe_Tank { get { return truppe_Tank; } }

        // Truppe Elite
        public List<Truppa_Elite> Truppe_Elite { get { return truppe_Elite; } }

        // Struttue

        //  Fornace
        public Fornace Fornace { get { return fornace; } }

        // Altare
        public Altare Altare { get { return altare; } }


    }
}
