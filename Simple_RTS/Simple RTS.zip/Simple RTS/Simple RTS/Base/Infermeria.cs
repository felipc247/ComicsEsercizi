﻿using Simple_RTS.Truppe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Base
{
    internal class Infermeria
    {
        private Giocatore giocatore;

        public Infermeria() { }

        public void SetUp(Giocatore giocatore) { 
            this.giocatore = giocatore;
        }

        public void PrintTru() { }

    }

}
