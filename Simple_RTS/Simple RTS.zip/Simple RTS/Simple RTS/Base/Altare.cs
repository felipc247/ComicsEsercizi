﻿using Simple_RTS.Exceptions.Risorse;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Base
{
    // Dove puoi evocare Eroi in cambio di Anime
    internal class Altare
    {
        private int anime_ATK = 0;
        private int anime_DIF = 0;
        private int luce_BLU = 100;
        private int produzione = 100;
        private int limite = 1000;

        public Altare() { }

        // GET // SET
        public int Anime_ATK
        {
            get { return anime_ATK; }
            set { anime_ATK = (anime_ATK + value < 0) ? 0 : anime_ATK + value; }
        }

        public int Anime_DIF
        {
            get { return anime_DIF; }
            set { anime_DIF = (anime_DIF + value < 0) ? 0 : anime_DIF + value; }
        }

        public int Luce_BLU
        {
            get { return luce_BLU; }
            set
            {
                if (luce_BLU + value > limite) { if (luce_BLU == 1000) throw new LuceBluMaxException(); luce_BLU = limite; }
                else
                { luce_BLU = (luce_BLU + value < 0) ? 0 : luce_BLU + value; }
            }
        }

        public int Limite {
            get { return limite; }
        }

        // METODI

        public void FuriaDivina()
        {
            int luce_BLUTemp = luce_BLU;
            if (Luce_BLU + produzione > limite)
            {
                CC.BlueFr("Furia Divina: "); CC.WhiteFr($"+ {0} Luce Blu\n");
            }
            else
            {
                CC.BlueFr("Furia Divina: "); CC.WhiteFr($"+ {produzione} Luce Blu\n");
            }

            try
            {
                Luce_BLU = produzione;
            }
            catch (LuceBluMaxException) { }    

            CC.WhiteFr($"Luce Blu {luce_BLUTemp} => {luce_BLU}\n");
        }


    }
}
