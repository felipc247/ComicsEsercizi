﻿using Simple_RTS.Exceptions;
using Simple_RTS.Exceptions.Frammenti;
using Simple_RTS.Exceptions.Input;
using Simple_RTS.Exceptions.Risorse;
using Simple_RTS.Exceptions.Truppe;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Base
{
    // Luogo di scambi
    internal class Mercato
    {
        private Giocatore giocatore;
        // Dictionary per contenere i vari slots del mercato
        private Dictionary<string, string> slots = new Dictionary<string, string> {
            { "Truppe", "Potenzia le tue Truppe" },
            { "Luce Blu", "Scambia Frammenti in cambio di Luce Blu"},
            { "Sacrificio Blu", "Sacrifica le tue Truppe in cambio di Luce Blu"},
            { "Truppe Elite", "Assolda potenti Truppe Elite"},
            { "Produzione", "Migliora la Produzione della Fornace"},
        };

        public Mercato(Giocatore giocatore)
        {
            this.giocatore = giocatore;
        }

        // stampa tutti gli slot con formattazione
        public void PrintSlots()
        {
            int i = 1;
            foreach (var slot in slots)
            {
                CC.DarkCyanFr(i++ + ". " + slot.Key); CC.CyanFr(" => "); CC.WhiteFr(slot.Value + "\n");
            }
        }

        // Consente di scegliere uno slot del mercato
        public void SceltaSlot()
        {
            int scelta;
            do
            {
                scelta = -1;
                try
                {
                    // stampa slots
                    CC.CyanFr("Cosa vuoi fare?\n");
                    PrintSlots();

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 1 || scelta > slots.Count) throw new NumeroNonValidoException();

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            PrintPotenziaTruppe();
                            break;
                        case 2:
                            PrintScambioBlu();
                            break;
                        case 3:
                            break;
                        case 4:
                            break;
                        case 5:
                            break;

                    }
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { }
                catch (NumeroNonValidoException) { }
                finally { if (scelta < 1 || scelta > slots.Count) scelta = -1; }

            } while (scelta == -1);
        }

        // Quantita' e prezzi Luce Blu
        int[] qt = { 100, 300, 700 };
        int[] prices = { 1000, 2950, 6500 };

        public void PrintQuantitaLuceBlu()
        {
            for (int i = 0; i < qt.Length; i++)
            {
                CC.BlueFr($"{i + 1}. {qt[i]} Luce Blu");

                if (giocatore.Fornace.Frammenti < prices[i])
                {
                    CC.RedFr($" | {prices[i]} Frammenti\n");
                }
                else
                {
                    CC.WhiteFr($" | {prices[i]} Frammenti\n");
                }

            }
        }

        public void ScambioBlu(int scelta)
        {
            int frammenti = giocatore.Fornace.Frammenti;
            int luce_Blu = giocatore.Altare.Luce_BLU;

            giocatore.Fornace.Frammenti = -prices[scelta - 1];
            giocatore.Altare.Luce_BLU = qt[scelta - 1];

            CC.GreenFr("Successo!\n");
            CC.WhiteFr($"Frammenti {frammenti} => {giocatore.Fornace.Frammenti}\n");
            CC.WhiteFr($"Luce Blu {luce_Blu} => {giocatore.Altare.Luce_BLU}\n");

        }

        public void PrintScambioBlu()
        {
            int scelta;

            do
            {
                scelta = -1;
                try
                {
                    // stampa scambi disponibili
                    CC.CyanFr("Scegli la quantita'\n");
                    PrintQuantitaLuceBlu();
                    CC.BlueFr("0. Mostra Frammenti\n");
                    CC.BlueFr($"{prices.Length + 1}. Esci\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 0 || scelta > prices.Length + 1) throw new NumeroNonValidoException();

                    // Frammenti insufficienti, si esce dal ciclo
                    if (scelta != 0 && scelta != prices.Length + 1)
                        if (giocatore.Fornace.Frammenti < prices[scelta - 1]) throw new FrammentiInsufficientiException();

                    // Luce Blu Max, si esce dal ciclo
                    if (giocatore.Altare.Luce_BLU == giocatore.Altare.Limite) throw new LuceBluMaxException();

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            ScambioBlu(scelta);
                            break;
                        case 2:
                            ScambioBlu(scelta);
                            break;
                        case 3:
                            ScambioBlu(scelta);
                            break;                        
                        case 0:
                            CC.GreenFr($"Frammenti: {giocatore.Fornace.Frammenti}\n");
                            scelta = -1;
                            break;
                        case 4:
                            break;

                    }
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { }
                catch (NumeroNonValidoException) { }
                catch (FrammentiInsufficientiException) { break; }
                catch (LuceBluMaxException) { break; }
                finally { if (scelta < 1 || scelta > slots.Count) scelta = -1; }

            } while (scelta == -1);
        }

        public void PrintTipologieTruppe()
        {
            int i = 1;

            // TRUPPE MISCHIA
            CC.DarkYellowFr($"{i++}. {giocatore.Truppe_Mischia[0].Tipologia}\n");

            // TRUPPE DISTANZA
            CC.DarkCyanFr($"{i++}. {giocatore.Truppe_Distanza[0].Tipologia}\n");

            // TRUPPE TANK
            CC.DarkMagentaFr($"{i++}. {giocatore.Truppe_Tank[0].Tipologia}\n");

        }

        // Stampa le Truppe di una Tipologia, con Lvl e costo potenziamento
        public void PrintTruppe(List<Truppa> truppas)
        {
            int i = 1;
            foreach (var truppa in truppas)
            {
                // stampo Nome Truppa, il colore cambia in base alla Tipologia
                switch (truppa.Tipologia)
                {
                    case Truppa.TT.Mischia:
                        CC.YellowFr($"{i++} . {truppa.Nome}");
                        break;
                    case Truppa.TT.Distanza:
                        CC.CyanFr($"{i++} . {truppa.Nome}");
                        break;
                    case Truppa.TT.Tank:
                        CC.MagentaFr($"{i++} . {truppa.Nome}");
                        break;
                }

                // Stampo effetto potenziamento Lvl. 1 => Lvl. 2
                if (truppa.Livello < truppa.Costi_Potenziamento.Length + 1)
                {
                    CC.WhiteFr($" | Lvl. {truppa.Livello} => ");
                    CC.GreenFr($"Lvl. {truppa.Livello + 1}");
                    CC.WhiteFr(" | ");
                }
                else
                {
                    // Stampo solo il livello corrente se Lvl. MAX
                    CC.WhiteFr($" | Lvl. {truppa.Livello} | ");
                }

                // Stampo il costo Potenziamento o Livello MAX
                if (truppa.Livello == truppa.Costi_Potenziamento.Length + 1)
                {
                    CC.GreenFr($"Livello MAX\n");
                }
                else if (truppa.Costo_Potenziamento > giocatore.Fornace.Frammenti)
                {
                    CC.RedFr($"Costo {truppa.Costo_Potenziamento}\n");
                }
                else
                {
                    CC.WhiteFr($"Costo {truppa.Costo_Potenziamento}\n");
                }
            }
        }


        public void PotenziaTruppe(List<Truppa> truppe)
        {
            int scelta;

            do
            {
                scelta = -1;
                try
                {

                    // Stampa Truppe Mischia
                    CC.CyanFr("Quale classe vuoi potenziare?\n");
                    PrintTruppe(truppe);

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 1 || scelta > truppe.Count) throw new NumeroNonValidoException();

                    // Frammenti insufficienti, si esce dal ciclo
                    if (giocatore.Fornace.Frammenti < truppe[scelta - 1].Costo_Potenziamento)
                        throw new FrammentiInsufficientiException();

                    // Truppa Lvl MAX, si esce dal ciclo
                    if (truppe[scelta - 1].Livello == truppe[scelta - 1].Costi_Potenziamento.Length + 1)
                        throw new TruppaLivelloMassimoException();

                    // se tutto va bene si procede
                    int frammenti = giocatore.Fornace.Frammenti;
                    giocatore.Fornace.Frammenti = -truppe[scelta - 1].Costo_Potenziamento;
                    CC.WhiteFr($"Frammenti {frammenti} => {giocatore.Fornace.Frammenti}\n");

                    truppe[scelta - 1].Potenzia();
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { }
                catch (NumeroNonValidoException) { }
                catch (FrammentiInsufficientiException) { break; }
                catch (TruppaLivelloMassimoException) { break; }
                finally { if (scelta < 1 || scelta > slots.Count) scelta = -1; }

            } while (scelta == -1);
        }

        // Consente di potenziare le Truppe per Frammenti
        // Per potenziare una Classe di Truppe deve essere nel tuo esercito
        public void PrintPotenziaTruppe()
        {
            int scelta;

            do
            {
                scelta = -1;
                try
                {

                    // Stampa Truppe
                    CC.CyanFr("Cosa vuoi potenziare?\n");
                    PrintTipologieTruppe();
                    CC.BlueFr("0. Mostra Frammenti\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 0 || scelta > slots.Count) throw new NumeroNonValidoException();

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            PotenziaTruppe(giocatore.Truppe_Mischia);
                            break;
                        case 2:
                            PotenziaTruppe(giocatore.Truppe_Distanza);
                            break;
                        case 3:
                            PotenziaTruppe(giocatore.Truppe_Tank);
                            break;
                        case 0:
                            CC.GreenFr($"Frammenti: {giocatore.Fornace.Frammenti}\n");
                            scelta = -1;
                            break;

                    }
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { }
                catch (NumeroNonValidoException) { }
                finally { if (scelta < 1 || scelta > slots.Count) scelta = -1; }

            } while (scelta == -1);

        }
    }
}
