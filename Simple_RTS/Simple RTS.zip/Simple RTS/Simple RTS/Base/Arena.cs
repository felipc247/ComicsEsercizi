﻿using Simple_RTS.Exceptions.Input;
using Simple_RTS.Exceptions;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Simple_RTS.Exceptions.Truppe;
using Simple_RTS.Exceptions.Frammenti;

namespace Simple_RTS.Base
{
    // Dove si assoldano Truppe
    internal class Arena
    {
        private Giocatore giocatore;
        private Mercato mercato;

        public Arena()
        {

        }

        public void SetUp(Giocatore giocatore, Mercato mercato)
        {
            this.giocatore = giocatore;
            this.mercato = mercato;
        }

        public void PrintTruppeAssoldaTruppe(List<Truppa> truppas)
        {
            int i = 1;
            switch (truppas[0].Tipologia)
            {
                case Truppa.TT.Mischia:
                    CC.DarkYellowFr("Truppe Mischia:\n");
                    foreach (var t in truppas)
                    {
                        CC.YellowFr($"{i++}. {t.Nome}");
                        CC.BlueFr($" - {t.Costo} Frammenti");
                        CC.WhiteFr($" | Al momento hai Qt. {t.Quantita}\n");

                    }
                    break;
                case Truppa.TT.Distanza:
                    CC.DarkCyanFr("Truppe Distanza:\n");
                    foreach (var t in truppas)
                    {
                        CC.CyanFr($"{i++}. {t.Nome}");
                        CC.BlueFr($" - {t.Costo} Frammenti");
                        CC.WhiteFr($" | Al momento hai Qt. {t.Quantita}\n");
                    }
                    break;
                case Truppa.TT.Tank:
                    CC.DarkMagentaFr("Truppe Tank:\n");
                    foreach (var t in truppas)
                    {
                        CC.MagentaFr($"{i++}. {t.Nome}");
                        CC.BlueFr($" - {t.Costo} Frammenti");
                        CC.WhiteFr($" | Al momento hai Qt. {t.Quantita}\n");
                    }
                    break;
            }
        }

        public int AssoldaTruppe(List<Truppa> truppe)
        {
            int scelta;
            int truppeCount = truppe.Count;
            do
            {
                scelta = -1;
                try
                {
                    // Stampa Classi Truppe della Tipologia scelta
                    PrintTruppeAssoldaTruppe(truppe);
                    CC.BlueFr("0. Indietro\n");
                    CC.BlueFr($"{truppeCount + 1}. Frammenti\n");

                    CC.CyanFr("Inserisci 'numTruppa'.'Quantita'\n" +
                        "Invio e ripeti per altre Truppe\n" +
                        "Invio senza nulla per terminare\n");

                    int qt = 0;
                    // per salvare le truppe e le quantita scelta dall'utente
                    Dictionary<int, int> qts = new Dictionary<int, int>();

                    String sceltaStr;

                    bool first = true;

                    do
                    {
                        // lettura scelta
                        sceltaStr = Console.ReadLine();

                        if (first)
                        {
                            // se al primo input non si inserisce nulla
                            // allora exception
                            first = false;
                            if (sceltaStr.Equals("")) throw new StringaVuotaException();
                        }
                        else
                        {
                            // se non si inserisce nulla dopo, allora fine input
                            if (sceltaStr.Equals("")) break;
                        }

                        // Tentativo di split
                        String[] input = sceltaStr.Split('.');

                        // gestione eccezioni input

                        if (!int.TryParse(input[0], out scelta)) throw new InputNonValidoException();
                        if (scelta < 0 || scelta > truppeCount + 1) throw new NumeroNonValidoException();
                        if (scelta == 0) break;
                        if (scelta == truppeCount + 1) break;
                        if (input.Length != 2) throw new FormattazioneNonValidaException();
                        if (!int.TryParse(input[1], out qt)) throw new InputNonValidoException();

                        // se tutto va bene aggiungo al Dictionary
                        if (qts.ContainsKey(scelta))
                        {
                            qts[scelta] += qt;
                        }
                        else
                        {
                            qts.Add(scelta, qt);
                        }

                    } while (true);

                    // indietro scelta == 0
                    if (scelta == 0) break;

                    // Mostro Frammenti e ripeto il ciclo
                    if (scelta == truppeCount + 1)
                    {
                        CC.GreenFr("Frammenti " + giocatore.Fornace.Frammenti + "\n");
                        scelta = -1;
                    }
                    else
                    {
                        // Stampa riepilogo assoldamento
                        int totale = 0;
                        int totale_Frammenti = 0;

                        CC.BlueFr("Assoldare queste Truppe?\n");
                        foreach (var item in qts)
                        {
                            CC.CyanFr($"{truppe[item.Key - 1].Nome}"); CC.WhiteFr($" => {item.Value}\n");
                            totale += item.Value;
                            totale_Frammenti += truppe[item.Key - 1].Costo * item.Value;
                        }

                        if (totale_Frammenti < 0) throw new NumeroNonValidoException();
                        CC.DarkYellowFr($"Totale: {totale} Truppe => ");
                        CC.BlueFr($"{totale_Frammenti} Frammenti\n");
                        
                        CC.WhiteFr("1. Si\n" +
                            "2. No\n");

                        sceltaStr = Console.ReadLine();
                        if (sceltaStr.Equals("")) throw new StringaVuotaException();
                        if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                        if (scelta < 1 || scelta > 2) throw new NumeroNonValidoException();

                        // Si
                        if (scelta == 1)
                        {                         
                            // Frammenti insufficienti
                            if (giocatore.Fornace.Frammenti < totale_Frammenti) throw new FrammentiInsufficientiException(); 

                            int frammenti = giocatore.Fornace.Frammenti;
                            giocatore.Fornace.Frammenti = -totale_Frammenti;
                            CC.YellowFr($"Frammenti {frammenti} => {giocatore.Fornace.Frammenti}\n");

                            foreach (var item in qts)
                            {
                                truppe[item.Key - 1].Disponibili = +item.Value;
                            }
                        }
                    }
                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                catch (FormattazioneNonValidaException) { scelta = -1; }
                catch (TruppeInsufficientiException) { }
                catch (FrammentiInsufficientiException) { }
                finally { if (scelta < 0 || scelta > 2) scelta = -1; }

            } while (scelta == -1);

            return scelta;
        }

        private void PrintTipologieTruppa()
        {
            int i = 1;

            // TRUPPE MISCHIA
            CC.DarkYellowFr($"{i++}. {giocatore.Truppe_Mischia[0].Tipologia}\n");

            // TRUPPE DISTANZA
            CC.DarkCyanFr($"{i++}. {giocatore.Truppe_Distanza[0].Tipologia}\n");

            // TRUPPE TANK
            CC.DarkMagentaFr($"{i++}. {giocatore.Truppe_Tank[0].Tipologia}\n");
        }

        public void PrintAssoldaTruppe()
        {
            CC.DarkGreenFr("||Assolda Truppe||\n");
            int scelta;
            int numTipologie = 3;
            do
            {
                scelta = -1;
                try
                {

                    // Stampa Truppe
                    CC.CyanFr("Cosa vuoi assoldare?\n");
                    PrintTipologieTruppa();
                    CC.BlueFr($"{numTipologie + 1}. Avanti\n");

                    // lettura scelta
                    String sceltaStr = Console.ReadLine();

                    // gestione eccezioni input
                    if (sceltaStr.Equals("")) throw new StringaVuotaException();
                    if (!int.TryParse(sceltaStr, out scelta)) throw new InputNonValidoException();
                    if (scelta < 0 || scelta > numTipologie + 1) throw new NumeroNonValidoException();

                    // Avanti
                    if (scelta == numTipologie + 1) break;

                    // se tutto va bene si procede
                    switch (scelta)
                    {
                        case 1:
                            scelta = AssoldaTruppe(giocatore.Truppe_Mischia);
                            break;
                        case 2:
                            scelta = AssoldaTruppe(giocatore.Truppe_Distanza);
                            break;
                        case 3:
                            scelta = AssoldaTruppe(giocatore.Truppe_Tank);
                            break;
                        
                    }
                    // se non si è scelto Avanti, si ripete il ciclo
                    scelta = -1;

                }
                catch (StringaVuotaException) { }
                catch (InputNonValidoException) { scelta = -1; }
                catch (NumeroNonValidoException) { }
                finally { if (scelta < 0 || scelta > numTipologie + 1) scelta = -1; }

            } while (scelta == -1);

            
        }


    }
}
