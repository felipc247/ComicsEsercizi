﻿using Simple_RTS.Truppe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Base
{
    // Dove si assoldano Truppe
    internal class Arena
    {
        private Giocatore giocatore;

        public Arena(Giocatore giocatore) {
            this.giocatore = giocatore;    
        }


    }
}
