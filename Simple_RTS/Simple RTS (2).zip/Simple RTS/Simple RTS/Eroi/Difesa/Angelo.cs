﻿using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS.Erori.Difesa
{
    internal class Angelo : Eroe
    {
        public Angelo() {
            base.nome = GetType().Name;
            base.nome_abilita = "Protezione Angelica";

            base.descrizione = "Un angelo caduto";

            base.descrizione_abilita = $"Le tue Truppe Distanza non possono subire danni questo turno";

            base.descrizione_uso_abilita = $"UwU! Truppe Distanza immuni ai danni questo turno";

            base.costo = 100;
            base.costo_abilita = 300;
            base.tipologia = TT.Difesa;
            base.cooldown = 3;
            base.cooldown_Rimanente = 0;
        }

        public override void Attiva()
        {
            base.Attiva();
            CC.BlueFr($"{base.nome_abilita} | {base.descrizione_uso_abilita}\n");
        }
    }
}
