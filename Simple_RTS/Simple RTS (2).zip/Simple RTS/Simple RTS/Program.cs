﻿using Simple_RTS.Base;
using Simple_RTS.Combattimento;
using Simple_RTS.Truppe;
using Simple_RTS.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_RTS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // GIOCATORE 1
            Altare altare1 = new Altare();
            Fornace fornace1 = new Fornace();
            Torre torre1 = new Torre();
            Arena arena1 = new Arena();
            Attacco attacco1 = new Attacco();

            // GIOCATORE 2
            Altare altare2 = new Altare();
            Fornace fornace2 = new Fornace();
            Torre torre2 = new Torre();


            Giocatore giocatore1 = new Giocatore("Anya");
            Giocatore giocatore2 = new Giocatore("Loid");

            giocatore1.SetUp(fornace1, altare1, torre1, torre2, giocatore2.Truppe_Mischia, giocatore2.Truppe_Distanza, giocatore2.Truppe_Tank);
            giocatore2.SetUp(fornace2, altare2, torre2, torre1, giocatore1.Truppe_Mischia, giocatore1.Truppe_Distanza, giocatore1.Truppe_Tank);

            giocatore1.Truppe_Mischia[0].Disponibili = 1500;
            giocatore2.Truppe_Mischia[0].Disponibili = 1500;
            giocatore1.Truppe_Mischia[1].Disponibili = 1500;
            giocatore2.Truppe_Mischia[1].Disponibili = 1500;
            giocatore1.Truppe_Distanza[0].Disponibili = 3000;
            giocatore2.Truppe_Distanza[0].Disponibili = 3000;
            giocatore2.Truppe_Distanza[0].Disponibili = 3000;
            giocatore2.Truppe_Distanza[0].Disponibili = 3000;

            Mercato mercato1 = new Mercato(giocatore1);
            arena1.SetUp(giocatore1, mercato1);
            altare1.SetUp(giocatore1);
            attacco1.SetUp(giocatore1, giocatore2);

            mercato1.SceltaSlot();
            arena1.PrintAssoldaTruppe();
            altare1.PrintEvocaEroi();
            attacco1.Preparazione(giocatore1);
            attacco1.AAAttacco();
            Mercato mercato2 = new Mercato(giocatore2);
        }
    }
}
