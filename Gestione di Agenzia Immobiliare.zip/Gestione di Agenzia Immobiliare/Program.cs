﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_di_Agenzia_Immobiliare
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Box box = new Box("123", "loc. wec 23", 52100,"AR", 30);
            Appartamento appartamento = new Appartamento("123", "loc. wec 23", 52100,"AR", 30, 3, 2);
            Console.WriteLine(appartamento.ToString());
        }
    }
}
